/* Jonathan Brugh
 * SNHU
 * CS-405 Secure Coding
 * Mod 4 Exceptions Activity
 * May 31, 2026
 */

// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    throw std::runtime_error("even_more_custom_application caused a runtime error.\n");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
try
{
    if (do_even_more_custom_application_logic())
    {
        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
}
catch(const std::exception& e)
{
    std::cout << "Error: " << e.what();
}
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw std::length_error("custom_application caused a logic error.");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    
    // Check for division by zero; throws exception if detected, does not stop app
    if (den == 0) {
        throw std::logic_error("Can't divide by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // try-catch block to detect exceptions from divide(); Does not stop app
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch(const std::exception& e)
    {
        std::cout << "Divide exception detected: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    // My custom exception catcher
    catch(const std::length_error& e)
    {
        std::cout << "Custom exception caught: " << e.what() << '\n';
    }
    // std::exception catcher
    catch(const std::exception& e)
    {
        std::cout << "Standard exception caught: " << e.what() << '\n';
    }
    // Catcher for all uncaught exceptions
    catch(...)
    {
        std::cout << "Uncaught exception caught: " << '\n';
    }
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
